"""klit-flow web portal.

Serves a single-page application (SPA) that visualises the dependency and
screen-flow graphs and exposes five REST endpoints consumed by the SPA:

- ``GET /``                     — SPA HTML (no external dependencies).
- ``GET /api/graph``            — all nodes and edges.
- ``GET /api/search?q=&k=``     — hybrid BM25 + semantic search.
- ``GET /api/flows?screen=``    — NAVIGATES_TO edges, optionally filtered.
- ``GET /api/node/{node_id}``   — one node with its inbound/outbound edges.

:func:`create_web_app` builds the FastAPI instance from pre-opened resources.
:func:`run_web_server` is the entry point used by the CLI (runs in a separate
process so it gets its own LadybugDB connection, avoiding the single-Database
constraint).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse

from klit_flow.graph.store import GraphStore
from klit_flow.index.bm25 import BM25Index
from klit_flow.index.search import hybrid_search

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Embedded SPA (no CDN, fully offline)
# ---------------------------------------------------------------------------

_SPA_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>klit-flow portal</title>
  <style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    :root{
      --bg:#0f172a;--surface:#1e293b;--border:#334155;
      --text:#e2e8f0;--muted:#64748b;--accent:#7c3aed;--accent-l:#a78bfa
    }
    body{background:var(--bg);color:var(--text);font-family:system-ui,-apple-system,sans-serif;
         height:100dvh;display:flex;flex-direction:column;overflow:hidden}

    /* Header */
    header{background:var(--surface);border-bottom:1px solid var(--border);
           padding:0 16px;height:48px;display:flex;align-items:center;gap:12px;flex-shrink:0}
    .logo{font-weight:700;font-size:.9rem;color:var(--accent-l);white-space:nowrap}
    .tabs{display:flex;gap:4px}
    .tab{background:none;border:none;color:var(--muted);padding:6px 12px;border-radius:6px;
         cursor:pointer;font-size:.85rem;transition:background .15s,color .15s}
    .tab:hover{background:#334155;color:var(--text)}
    .tab.active{background:var(--accent);color:#fff}
    #search-input{flex:1;max-width:360px;margin-left:auto;background:var(--bg);
                  border:1px solid var(--border);color:var(--text);padding:6px 12px;
                  border-radius:6px;font-size:.85rem;outline:none}
    #search-input:focus{border-color:var(--accent)}

    /* Layout */
    main{flex:1;display:flex;overflow:hidden;position:relative}
    .view{flex:1;display:none;overflow:hidden}
    .view.active{display:flex}

    /* Graph view */
    #graph-view{position:relative}
    #graph-canvas{width:100%;height:100%;display:block;cursor:grab}
    #graph-canvas:active{cursor:grabbing}
    .graph-controls{position:absolute;top:12px;right:12px;display:flex;flex-direction:column;gap:6px}
    .gc-btn{background:var(--surface);border:1px solid var(--border);color:var(--muted);
            width:32px;height:32px;border-radius:6px;cursor:pointer;font-size:1rem;
            display:flex;align-items:center;justify-content:center}
    .gc-btn:hover{color:var(--text);border-color:var(--accent)}
    .gc-btn.on{color:var(--accent-l);border-color:var(--accent-l)}
    .legend{position:absolute;bottom:12px;left:12px;background:#1e293bcc;
            border:1px solid var(--border);border-radius:8px;padding:10px 14px;
            font-size:.75rem;backdrop-filter:blur(4px)}
    .li{display:flex;align-items:center;gap:8px;margin-bottom:4px}
    .li:last-child{margin-bottom:0}
    .dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}

    /* Sidebar */
    #sidebar{width:0;background:var(--surface);border-left:1px solid var(--border);
             overflow:hidden;transition:width .2s ease;flex-shrink:0}
    #sidebar.open{width:280px}
    #sb-inner{width:280px;padding:16px;overflow-y:auto;height:100%}
    #sb-inner .close-btn{float:right;background:none;border:none;color:var(--muted);
                         cursor:pointer;font-size:1rem;padding:0}
    #sb-inner .close-btn:hover{color:var(--text)}
    .sb-badge{display:inline-flex;align-items:center;padding:2px 7px;border-radius:4px;
              font-size:.72rem;font-weight:600;margin-bottom:6px}
    #sb-inner h2{font-size:.9rem;font-weight:600;margin-bottom:2px}
    #sb-inner .meta{font-size:.75rem;color:var(--muted);margin-bottom:12px;word-break:break-all}
    .es{margin-top:14px}
    .es h3{font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.06em;
           color:var(--muted);margin-bottom:6px}
    .er{display:flex;justify-content:space-between;align-items:center;padding:5px 0;
        border-bottom:1px solid #33415522;cursor:pointer;font-size:.8rem}
    .er:hover{color:var(--accent-l)}
    .er .et{font-size:.7rem;color:var(--muted)}

    /* Table views */
    .tv{flex:1;overflow-y:auto;padding:20px;flex-direction:column}
    .tv h2{font-size:.95rem;font-weight:600;margin-bottom:14px}
    .fr{display:flex;gap:8px;margin-bottom:12px;align-items:center}
    .fr input{background:var(--bg);border:1px solid var(--border);color:var(--text);
              padding:5px 10px;border-radius:6px;font-size:.8rem;flex:1;max-width:300px;outline:none}
    .fr input:focus{border-color:var(--accent)}
    .fr button{background:var(--surface);border:1px solid var(--border);color:var(--muted);
               padding:5px 10px;border-radius:6px;font-size:.8rem;cursor:pointer}
    .fr button:hover{color:var(--text)}
    table{width:100%;border-collapse:collapse;font-size:.83rem}
    th{text-align:left;padding:8px 12px;background:var(--surface);color:var(--muted);
       font-weight:500;font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;
       border-bottom:1px solid var(--border);position:sticky;top:0;z-index:1}
    td{padding:8px 12px;border-bottom:1px solid #33415533;vertical-align:middle}
    tr:hover td{background:#1e293b66;cursor:pointer}
    .badge{display:inline-flex;align-items:center;padding:2px 7px;border-radius:4px;
           font-size:.72rem;font-weight:600}
    .none{color:var(--muted);font-size:.8rem}
    .empty-td{color:var(--muted);font-size:.85rem;padding:20px 12px}

    /* Tooltip */
    #tip{position:fixed;background:var(--surface);border:1px solid var(--border);
         border-radius:6px;padding:6px 10px;font-size:.78rem;pointer-events:none;
         opacity:0;transition:opacity .1s;z-index:999;max-width:260px;line-height:1.4}
    #tip.on{opacity:1}

    /* Loading */
    #loading{position:absolute;inset:0;display:flex;flex-direction:column;
             align-items:center;justify-content:center;background:var(--bg);gap:12px;z-index:10}
    #loading p{color:var(--muted);font-size:.85rem}
    .spin{width:32px;height:32px;border:3px solid var(--border);
          border-top-color:var(--accent);border-radius:50%;animation:sp .8s linear infinite}
    @keyframes sp{to{transform:rotate(360deg)}}
  </style>
</head>
<body>
<header>
  <span class="logo">&#x2B21; klit-flow</span>
  <nav class="tabs">
    <button class="tab active" data-view="graph">Graph</button>
    <button class="tab" data-view="flows">Flows</button>
    <button class="tab" data-view="search">Search</button>
  </nav>
  <input id="search-input" type="search" placeholder="Search symbols\u2026" autocomplete="off">
</header>
<main>
  <!-- Graph -->
  <div id="graph-view" class="view active">
    <div id="loading"><div class="spin"></div><p>Loading graph\u2026</p></div>
    <canvas id="graph-canvas"></canvas>
    <div class="graph-controls">
      <button class="gc-btn" id="btn-zin" title="Zoom in">+</button>
      <button class="gc-btn" id="btn-zout" title="Zoom out">\u2212</button>
      <button class="gc-btn" id="btn-fit" title="Fit">\u229e</button>
      <button class="gc-btn" id="btn-scr" title="Show screens only" style="font-size:.7rem">SCR</button>
    </div>
    <div class="legend">
      <div class="li"><div class="dot" style="background:#a78bfa"></div>Screen</div>
      <div class="li"><div class="dot" style="background:#34d399"></div>Class</div>
      <div class="li"><div class="dot" style="background:#38bdf8"></div>File</div>
      <div class="li"><div class="dot" style="background:#fb923c"></div>Function</div>
      <div class="li"><div class="dot" style="background:#f472b6"></div>Method</div>
    </div>
  </div>

  <!-- Flows -->
  <div id="flows-view" class="view tv" style="display:none">
    <h2>Navigation Flows</h2>
    <div class="fr">
      <input id="flows-q" type="search" placeholder="Filter by screen name\u2026" autocomplete="off">
      <button id="flows-reset">All</button>
    </div>
    <table>
      <thead><tr><th>From</th><th>To</th><th>Trigger</th><th>Confidence</th></tr></thead>
      <tbody id="flows-body"></tbody>
    </table>
  </div>

  <!-- Search -->
  <div id="search-view" class="view tv" style="display:none">
    <h2>Search Results</h2>
    <table>
      <thead><tr><th>Kind</th><th>Name</th><th>File</th></tr></thead>
      <tbody id="search-body"><tr><td colspan="3" class="empty-td">Type a query above.</td></tr></tbody>
    </table>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div id="sb-inner">
      <button class="close-btn" id="sb-close">\u2715</button>
      <div id="sb-content"><p class="none">Click a node to inspect it.</p></div>
    </div>
  </div>
</main>
<div id="tip"></div>

<script>
'use strict';
// ── Palette ───────────────────────────────────────────────────────────────────
const KC={Screen:'#a78bfa',Class:'#34d399',File:'#38bdf8',
          Function:'#fb923c',Method:'#f472b6',Module:'#94a3b8',Interface:'#fbbf24'};
const NODE_R={Screen:14,File:9,Module:9};
const DEF_R=6;
function kc(k){return KC[k]||'#94a3b8'}
function nr(n){return NODE_R[n.kind]||DEF_R}

// ── State ─────────────────────────────────────────────────────────────────────
let allNodes=[],allEdges=[],simEdges=[];
let visNodes=[];
let nodeById={};
let selected=null,showScrOnly=false;
let pan={x:0,y:0},zoom=1;
let dragNode=null,panStart=null,mdPt=null;
let simAlpha=0,simRunning=false;

// ── Canvas ────────────────────────────────────────────────────────────────────
const canvas=document.getElementById('graph-canvas');
const ctx=canvas.getContext('2d');
function resize(){
  const p=canvas.parentElement;
  canvas.width=p.clientWidth; canvas.height=p.clientHeight; draw();
}
new ResizeObserver(resize).observe(canvas.parentElement);

// ── API ───────────────────────────────────────────────────────────────────────
async function api(url){
  const r=await fetch(url);
  if(!r.ok) throw new Error('HTTP '+r.status);
  return r.json();
}
function esc(s){
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
                  .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function base(fp){return fp?fp.replace(/\\\\/g,'/').split('/').pop():''}

function badge(kind){
  const c=kc(kind);
  return `<span class="badge" style="background:${c}22;color:${c}">${esc(kind)}</span>`;
}

// ── Graph load ────────────────────────────────────────────────────────────────
async function loadGraph(){
  document.getElementById('loading').style.display='flex';
  try{
    const d=await api('/api/graph');
    allNodes=d.nodes; allEdges=d.edges;
    nodeById=Object.fromEntries(allNodes.map(n=>[n.id,n]));
    applyFilter();
    document.getElementById('loading').style.display='none';
  }catch(e){
    document.getElementById('loading').innerHTML=
      `<p style="color:#f87171">Failed to load: ${esc(e.message)}</p>`;
  }
}

function applyFilter(){
  visNodes=showScrOnly?allNodes.filter(n=>n.kind==='Screen'):allNodes;
  const ids=new Set(visNodes.map(n=>n.id));
  const W=canvas.width||800,H=canvas.height||600;
  visNodes.forEach((n,i)=>{
    if(n.x===undefined){
      const a=(2*Math.PI*i)/visNodes.length;
      const r=Math.min(W,H)*0.3;
      n.x=W/2+r*Math.cos(a)+(Math.random()-.5)*30;
      n.y=H/2+r*Math.sin(a)+(Math.random()-.5)*30;
      n.vx=0; n.vy=0;
    }
  });
  simEdges=allEdges
    .filter(e=>ids.has(e.src)&&ids.has(e.dst))
    .map(e=>({...e,s:nodeById[e.src],t:nodeById[e.dst]}))
    .filter(e=>e.s&&e.t);
  startSim();
}

// ── Simulation ────────────────────────────────────────────────────────────────
function startSim(){simAlpha=1;if(!simRunning){simRunning=true;requestAnimationFrame(step)}}

function step(){
  if(simAlpha<0.008){simRunning=false;draw();return}
  simAlpha*=0.96;
  const ns=visNodes,es=simEdges;
  ns.forEach(n=>{n.fx=0;n.fy=0});
  // Repulsion
  for(let i=0;i<ns.length;i++){
    const a=ns[i];
    for(let j=i+1;j<ns.length;j++){
      const b=ns[j];
      const dx=b.x-a.x,dy=b.y-a.y,d2=dx*dx+dy*dy||1,d=Math.sqrt(d2);
      const f=3000/d2;
      const fx=dx/d*f,fy=dy/d*f;
      a.fx-=fx;a.fy-=fy;b.fx+=fx;b.fy+=fy;
    }
  }
  // Springs
  for(const e of es){
    const dx=e.t.x-e.s.x,dy=e.t.y-e.s.y,d=Math.sqrt(dx*dx+dy*dy)||1;
    const f=(d-120)*0.05,fx=dx/d*f,fy=dy/d*f;
    e.s.fx+=fx;e.s.fy+=fy;e.t.fx-=fx;e.t.fy-=fy;
  }
  // Centre
  const W=canvas.width,H=canvas.height;
  ns.forEach(n=>{n.fx+=(W/2-n.x)*.003;n.fy+=(H/2-n.y)*.003});
  // Integrate
  ns.forEach(n=>{
    if(n===dragNode)return;
    n.vx=(n.vx+n.fx)*.7;n.vy=(n.vy+n.fy)*.7;
    n.x+=n.vx*simAlpha;n.y+=n.vy*simAlpha;
  });
  draw();
  requestAnimationFrame(step);
}

// ── Draw ──────────────────────────────────────────────────────────────────────
function draw(){
  const W=canvas.width,H=canvas.height;
  ctx.clearRect(0,0,W,H);
  ctx.save();
  ctx.translate(pan.x,pan.y);
  ctx.scale(zoom,zoom);

  // Edges
  for(const e of simEdges){
    const nav=e.type==='NAVIGATES_TO';
    const alpha=nav?0.85:0.3;
    const col=nav?'#a78bfa':'#475569';
    ctx.beginPath();
    ctx.moveTo(e.s.x,e.s.y);
    if(nav){
      const mx=(e.s.x+e.t.x)/2-(e.t.y-e.s.y)*.15;
      const my=(e.s.y+e.t.y)/2+(e.t.x-e.s.x)*.15;
      ctx.quadraticCurveTo(mx,my,e.t.x,e.t.y);
    }else{
      ctx.lineTo(e.t.x,e.t.y);
    }
    ctx.strokeStyle=col+Math.round(alpha*255).toString(16).padStart(2,'0');
    ctx.lineWidth=nav?1.5:.8;
    ctx.stroke();
    if(nav) drawArrow(e.s,e.t);
  }

  // Nodes
  for(const n of visNodes){
    const r=nr(n),c=kc(n.kind),sel=selected&&selected.id===n.id;
    if(sel){
      ctx.beginPath();ctx.arc(n.x,n.y,r+5,0,Math.PI*2);
      ctx.fillStyle=c+'33';ctx.fill();
    }
    ctx.beginPath();ctx.arc(n.x,n.y,r,0,Math.PI*2);
    ctx.fillStyle=sel?c:c+'99';ctx.fill();
    ctx.strokeStyle=c;ctx.lineWidth=sel?2:1;ctx.stroke();
    if(zoom>0.6&&n.kind!=='Method'&&n.kind!=='Function'){
      const lbl=n.name.length>16?n.name.slice(0,14)+'\u2026':n.name;
      ctx.font=`${Math.round(10/zoom)}px system-ui`;
      ctx.textAlign='center';ctx.fillStyle='#cbd5e1';
      ctx.fillText(lbl,n.x,n.y+r+11/zoom);
    }
  }
  ctx.restore();
}

function drawArrow(s,t){
  const ang=Math.atan2(t.y-s.y,t.x-s.x);
  const r=nr(t)+2;
  const ax=t.x-Math.cos(ang)*r,ay=t.y-Math.sin(ang)*r;
  ctx.beginPath();
  ctx.moveTo(ax-Math.cos(ang-.45)*7,ay-Math.sin(ang-.45)*7);
  ctx.lineTo(ax,ay);
  ctx.lineTo(ax-Math.cos(ang+.45)*7,ay-Math.sin(ang+.45)*7);
  ctx.strokeStyle='#a78bfacc';ctx.lineWidth=1.5;ctx.stroke();
}

// ── Hit test ──────────────────────────────────────────────────────────────────
function wp(cx,cy){
  const rc=canvas.getBoundingClientRect();
  return{x:(cx-rc.left-pan.x)/zoom,y:(cy-rc.top-pan.y)/zoom};
}
function hit(pt){
  for(let i=visNodes.length-1;i>=0;i--){
    const n=visNodes[i],r=nr(n)+4;
    const dx=n.x-pt.x,dy=n.y-pt.y;
    if(dx*dx+dy*dy<=r*r)return n;
  }
  return null;
}

// ── Interaction ───────────────────────────────────────────────────────────────
canvas.addEventListener('mousedown',e=>{
  e.preventDefault();
  mdPt={cx:e.clientX,cy:e.clientY};
  const h=hit(wp(e.clientX,e.clientY));
  if(h){dragNode=h}
  else{panStart={cx:e.clientX,cy:e.clientY,px:pan.x,py:pan.y}}
});

canvas.addEventListener('mousemove',e=>{
  if(dragNode){
    const p=wp(e.clientX,e.clientY);
    dragNode.x=p.x;dragNode.y=p.y;dragNode.vx=0;dragNode.vy=0;
    if(!simRunning)draw();return;
  }
  if(panStart){
    pan.x=panStart.px+(e.clientX-panStart.cx);
    pan.y=panStart.py+(e.clientY-panStart.cy);
    if(!simRunning)draw();return;
  }
  const h=hit(wp(e.clientX,e.clientY));
  const tip=document.getElementById('tip');
  if(h){
    tip.innerHTML=`<strong>${esc(h.name)}</strong><br><span style="color:#64748b">${esc(h.kind)} \u00b7 ${esc(base(h.file))}</span>`;
    tip.style.left=(e.clientX+14)+'px';tip.style.top=(e.clientY-10)+'px';
    tip.classList.add('on');
  }else{tip.classList.remove('on')}
});

canvas.addEventListener('mouseup',e=>{
  const dn=dragNode,ps=panStart;
  dragNode=null;panStart=null;
  if(!mdPt)return;
  const dx=e.clientX-mdPt.cx,dy=e.clientY-mdPt.cy;
  mdPt=null;
  if(dx*dx+dy*dy>25)return;
  const h=hit(wp(e.clientX,e.clientY));
  if(h)selNode(h);else desel();
});

canvas.addEventListener('mouseleave',()=>{
  document.getElementById('tip').classList.remove('on');
  dragNode=null;panStart=null;
});

canvas.addEventListener('wheel',e=>{
  e.preventDefault();
  const f=e.deltaY>0?.88:1.14;
  const rc=canvas.getBoundingClientRect();
  const cx=e.clientX-rc.left,cy=e.clientY-rc.top;
  pan.x=cx-(cx-pan.x)*f;pan.y=cy-(cy-pan.y)*f;
  zoom=Math.max(.15,Math.min(5,zoom*f));
  if(!simRunning)draw();
},{passive:false});

document.getElementById('btn-zin').addEventListener('click',()=>{zoom=Math.min(5,zoom*1.25);if(!simRunning)draw()});
document.getElementById('btn-zout').addEventListener('click',()=>{zoom=Math.max(.15,zoom/1.25);if(!simRunning)draw()});
document.getElementById('btn-fit').addEventListener('click',fitView);
document.getElementById('btn-scr').addEventListener('click',()=>{
  showScrOnly=!showScrOnly;
  document.getElementById('btn-scr').classList.toggle('on',showScrOnly);
  applyFilter();
});

function fitView(){
  if(!visNodes.length)return;
  const xs=visNodes.map(n=>n.x),ys=visNodes.map(n=>n.y);
  const x0=Math.min(...xs),x1=Math.max(...xs);
  const y0=Math.min(...ys),y1=Math.max(...ys);
  const W=canvas.width,H=canvas.height,pad=60;
  zoom=Math.max(.15,Math.min(5,Math.min((W-pad*2)/(x1-x0||1),(H-pad*2)/(y1-y0||1))));
  pan.x=W/2-(x0+x1)/2*zoom;pan.y=H/2-(y0+y1)/2*zoom;
  if(!simRunning)draw();
}

// ── Node detail ───────────────────────────────────────────────────────────────
async function selNode(n){
  selected=n;if(!simRunning)draw();
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('sb-content').innerHTML='<p class="none">Loading\u2026</p>';
  try{
    const d=await api(`/api/node/${encodeURIComponent(n.id)}`);
    renderDet(d);
  }catch{
    document.getElementById('sb-content').innerHTML='<p class="none">Error loading details.</p>';
  }
}
function desel(){selected=null;if(!simRunning)draw()}

function renderDet({node,outbound,inbound}){
  const c=kc(node.kind);
  document.getElementById('sb-content').innerHTML=`
    <span class="sb-badge" style="background:${c}22;color:${c}">${esc(node.kind)}</span>
    <h2>${esc(node.name)}</h2>
    <div class="meta">${esc(base(node.file))} \u00b7 L${node.start_line}\u2013${node.end_line} \u00b7 ${esc(node.language||'')}</div>
    <div class="es">
      <h3>Outbound (${outbound.length})</h3>
      ${outbound.length?outbound.map(e=>`<div class="er" onclick="jumpTo('${esc(e.id)}')">\
<span>${esc(e.name)}</span><span class="et">${esc(e.type)}</span></div>`).join(''):'<span class="none">None</span>'}
    </div>
    <div class="es">
      <h3>Inbound (${inbound.length})</h3>
      ${inbound.length?inbound.map(e=>`<div class="er" onclick="jumpTo('${esc(e.id)}')">\
<span>${esc(e.name)}</span><span class="et">${esc(e.type)}</span></div>`).join(''):'<span class="none">None</span>'}
    </div>`;
}

function jumpTo(id){
  const n=visNodes.find(n=>n.id===id);
  if(!n){alert('Node not in current view. Disable the SCR filter to see all nodes.');return}
  pan.x=canvas.width/2-n.x*zoom;pan.y=canvas.height/2-n.y*zoom;
  selNode(n);if(!simRunning)draw();
}

document.getElementById('sb-close').addEventListener('click',()=>{
  document.getElementById('sidebar').classList.remove('open');desel();
});

// ── Views ─────────────────────────────────────────────────────────────────────
function showView(name){
  ['graph','flows','search'].forEach(v=>{
    const el=document.getElementById(v+'-view');
    const isG=v==='graph';
    const active=v===name;
    el.classList.toggle('active',active);
    el.style.display=active?(isG?'block':'flex'):'none';
  });
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
  if(name==='flows')loadFlows();
}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));

// ── Flows ─────────────────────────────────────────────────────────────────────
async function loadFlows(screen=''){
  const url=screen?`/api/flows?screen=${encodeURIComponent(screen)}`:'/api/flows';
  try{
    const d=await api(url);
    const tb=document.getElementById('flows-body');
    if(!d.flows.length){
      tb.innerHTML='<tr><td colspan="4" class="empty-td">No navigation edges found.</td></tr>';return;
    }
    tb.innerHTML=d.flows.map(f=>`<tr onclick="showFlowFor('${esc(f.from)}')">
      <td>${esc(f.from)}</td><td>${esc(f.to)}</td>
      <td><span class="badge" style="background:#a78bfa22;color:#a78bfa">${esc(f.trigger)}</span></td>
      <td>${(f.confidence*100).toFixed(0)}%</td></tr>`).join('');
  }catch(e){
    document.getElementById('flows-body').innerHTML=
      `<tr><td colspan="4" class="empty-td">Error: ${esc(e.message)}</td></tr>`;
  }
}
function showFlowFor(s){document.getElementById('flows-q').value=s;loadFlows(s)}
document.getElementById('flows-q').addEventListener('input',e=>{
  const v=e.target.value.trim();loadFlows(v||'');
});
document.getElementById('flows-reset').addEventListener('click',()=>{
  document.getElementById('flows-q').value='';loadFlows();
});

// ── Search ────────────────────────────────────────────────────────────────────
let stimer;
document.getElementById('search-input').addEventListener('input',e=>{
  clearTimeout(stimer);
  const q=e.target.value.trim();
  if(!q)return;
  showView('search');
  stimer=setTimeout(()=>doSearch(q),280);
});

async function doSearch(q){
  document.getElementById('search-body').innerHTML=
    '<tr><td colspan="3" class="empty-td">Searching\u2026</td></tr>';
  try{
    const d=await api(`/api/search?q=${encodeURIComponent(q)}`);
    if(!d.results.length){
      document.getElementById('search-body').innerHTML=
        '<tr><td colspan="3" class="empty-td">No results.</td></tr>';return;
    }
    document.getElementById('search-body').innerHTML=d.results.map(r=>`
      <tr onclick="jumpFromSearch('${esc(r.id)}')">
        <td>${badge(r.kind)}</td><td>${esc(r.name)}</td>
        <td style="color:#64748b;font-size:.78rem">${esc(base(r.file))}</td>
      </tr>`).join('');
  }catch(e){
    document.getElementById('search-body').innerHTML=
      `<tr><td colspan="3" class="empty-td">Error: ${esc(e.message)}</td></tr>`;
  }
}
function jumpFromSearch(id){showView('graph');jumpTo(id)}

// ── Boot ──────────────────────────────────────────────────────────────────────
loadGraph();
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# FastAPI application factory
# ---------------------------------------------------------------------------


def _esc(s: str) -> str:
    return s.replace("'", "\\'")


def create_web_app(store: GraphStore, bm25: BM25Index, embedder: Any) -> FastAPI:
    """Return a FastAPI application serving the SPA and REST API."""
    app = FastAPI(title="klit-flow portal", docs_url=None, redoc_url=None)

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def spa() -> str:
        return _SPA_HTML

    @app.get("/api/graph")
    async def get_graph() -> dict[str, Any]:
        nodes = store.query(
            "MATCH (n:KlitNode) RETURN n.id, n.kind, n.name, n.file_path, n.start_line"
        )
        edges = store.query(
            "MATCH (a:KlitNode)-[e:KlitEdge]->(b:KlitNode) "
            "RETURN a.id, b.id, e.type, e.confidence, e.trigger"
        )
        return {
            "nodes": [
                {"id": r[0], "kind": r[1], "name": r[2], "file": r[3], "start_line": r[4]}
                for r in nodes
            ],
            "edges": [
                {"src": r[0], "dst": r[1], "type": r[2], "confidence": r[3], "trigger": r[4]}
                for r in edges
            ],
        }

    @app.get("/api/search")
    async def search(q: str, k: int = 10) -> dict[str, Any]:
        node_ids = hybrid_search(q, bm25, store, embedder, k=k)
        results = []
        for nid in node_ids:
            rows = store.query(
                f"MATCH (n:KlitNode {{id: '{_esc(nid)}'}}) RETURN n.id, n.kind, n.name, n.file_path"
            )
            if rows:
                r = rows[0]
                results.append({"id": r[0], "kind": r[1], "name": r[2], "file": r[3]})
        return {"results": results}

    @app.get("/api/flows")
    async def get_flows(screen: str = "") -> dict[str, Any]:
        if screen:
            s = _esc(screen)
            rows = store.query(
                f"MATCH (a:KlitNode)-[e:KlitEdge]->(b:KlitNode) "
                f"WHERE e.type = 'NAVIGATES_TO' AND (a.name = '{s}' OR b.name = '{s}') "
                f"RETURN a.name, b.name, e.trigger, e.confidence ORDER BY a.name, b.name"
            )
        else:
            rows = store.query(
                "MATCH (a:KlitNode)-[e:KlitEdge]->(b:KlitNode) "
                "WHERE e.type = 'NAVIGATES_TO' "
                "RETURN a.name, b.name, e.trigger, e.confidence ORDER BY a.name, b.name"
            )
        return {
            "flows": [{"from": r[0], "to": r[1], "trigger": r[2], "confidence": r[3]} for r in rows]
        }

    @app.get("/api/node/{node_id}")
    async def get_node(node_id: str) -> dict[str, Any]:
        nid = _esc(node_id)
        rows = store.query(
            f"MATCH (n:KlitNode {{id: '{nid}'}}) "
            f"RETURN n.id, n.kind, n.name, n.file_path, n.start_line, n.end_line, n.language"
        )
        if not rows:
            raise HTTPException(status_code=404, detail="Node not found")
        r = rows[0]
        node = {
            "id": r[0],
            "kind": r[1],
            "name": r[2],
            "file": r[3],
            "start_line": r[4],
            "end_line": r[5],
            "language": r[6],
        }
        out = store.query(
            f"MATCH (a:KlitNode {{id: '{nid}'}}) -[e:KlitEdge]->(b:KlitNode) "
            f"RETURN e.type, b.id, b.name, b.kind"
        )
        inb = store.query(
            f"MATCH (a:KlitNode)-[e:KlitEdge]->(b:KlitNode {{id: '{nid}'}}) "
            f"RETURN e.type, a.id, a.name, a.kind"
        )
        return {
            "node": node,
            "outbound": [{"type": r[0], "id": r[1], "name": r[2], "kind": r[3]} for r in out],
            "inbound": [{"type": r[0], "id": r[1], "name": r[2], "kind": r[3]} for r in inb],
        }

    return app


# ---------------------------------------------------------------------------
# Process entry point (called from cli.py via multiprocessing)
# ---------------------------------------------------------------------------

_KLIT_DIR = ".klit-flow"
_DB_NAME = "graph.db"
_BM25_NAME = "bm25.pkl"


def run_web_server(target: Path, port: int) -> None:
    """Open the index for *target* and serve the web portal on *port*.

    Runs in a separate process so it gets its own LadybugDB connection.
    """
    import uvicorn

    from klit_flow.graph.store import LadybugGraphStore
    from klit_flow.index.bm25 import BM25Index
    from klit_flow.index.embeddings import Embedder

    klit_dir = target / _KLIT_DIR
    db_path = klit_dir / _DB_NAME
    bm25_path = klit_dir / _BM25_NAME

    store = LadybugGraphStore(db_path)
    bm25 = BM25Index.load(bm25_path) if bm25_path.exists() else _empty_bm25()
    embedder = Embedder()

    web_app = create_web_app(store, bm25, embedder)
    try:
        uvicorn.run(web_app, host="127.0.0.1", port=port, log_level="warning")
    finally:
        store.close()


def _empty_bm25() -> BM25Index:
    idx = BM25Index()
    idx.build()
    return idx
